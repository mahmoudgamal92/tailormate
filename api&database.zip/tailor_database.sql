-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 07, 2021 at 08:07 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user3153_tailor`
--

-- --------------------------------------------------------

--
-- Table structure for table `body_measurments`
--

CREATE TABLE `body_measurments` (
  `id` int(11) NOT NULL,
  `client_token` text COLLATE utf8_unicode_ci NOT NULL,
  `length` text COLLATE utf8_unicode_ci NOT NULL,
  `width` text COLLATE utf8_unicode_ci NOT NULL,
  `floor_width` text COLLATE utf8_unicode_ci NOT NULL,
  `shoulder` text COLLATE utf8_unicode_ci NOT NULL,
  `hand` text COLLATE utf8_unicode_ci NOT NULL,
  `hand_width` text COLLATE utf8_unicode_ci NOT NULL,
  `neck` text COLLATE utf8_unicode_ci NOT NULL,
  `kalab` text COLLATE utf8_unicode_ci NOT NULL,
  `sadah` text COLLATE utf8_unicode_ci NOT NULL,
  `cup` text COLLATE utf8_unicode_ci NOT NULL,
  `cup_width` text COLLATE utf8_unicode_ci NOT NULL,
  `cup_type` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `body_measurments`
--

INSERT INTO `body_measurments` (`id`, `client_token`, `length`, `width`, `floor_width`, `shoulder`, `hand`, `hand_width`, `neck`, `kalab`, `sadah`, `cup`, `cup_width`, `cup_type`, `date`) VALUES
(1, 'e33ab24347832d8dbd5a8424d01e7a46979696e2', '678', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(2, '45527467f009fd88ed06ef62857c3195d14cd0f9', '58', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(3, '6f1233f8d75f1a465c734ed131f40ea7abac8429', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(4, '3306c7cbdb444c8f296318f7f1f050d7ae6beb1b', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(5, '6764dff5b112afd6359ab0871a8cfeac19ab723e', '55', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(6, '0773a02b838f56deca442dc8f456c1829efff08e', '25', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(7, '201abd4fb60a03789ab0e033ce259c6769b72d86', '88', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(8, 'af22d5e0e172580e2d53ba1969a2ff4bcb936a33', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(9, 'd159d3715f3f85aca91a492a8abcfbf480c1ec45', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(10, '278ad4c141892afdc83a04222ea28d4dfa80cf6f', '111', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(11, '05414f9ef22d2119db349a6a37d10aba87e6ff8d', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(12, 'b6e238f6e112f20bdc4b68edb42d449b4696510a', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(13, 'c1c9d13b760deef67c094f2a63c45f1739589dde', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(14, 'f902d6bc0c422f6ece61eeb8dbcf1c25d0edea54', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(15, 'df9283b42fee6ac515b3a4e9aa4bf36437e9c339', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(16, '99c0338a4f7c24b695ca14099641b504fcbd6294', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(17, 'a263845c9307aef99c7d23207ce6b333da8ac731', '58', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(18, '1be08cec75862a9ece0fc09c833640adb22cfb15', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(19, '2db0d341d745c9537a03c9044c874237148b2ec2', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(20, '322021f7072c533e5d2316497377343fcd30e122', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(21, 'edd6928d9dabccdcb21ec2eec5126942f075e9a4', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(22, '283a24b206bcbacd0e2a15256928dd27a8a54d92', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(23, 'e87b6f6462c9f07c0fb099b44f2502121ee79f59', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(24, '3b2f91e13ca4497b4a50602419c2f04e66edf6d5', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(25, 'bd8744e358560284ef85b203853c0d989fcbd77d', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(26, '89379e045c5293e14a0d007e64f7236dcd49e270', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(27, '16be36dad7e6b482d1584d04e04b9f1c2b9a47da', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(28, 'c91cc24c3b0f29addb4e82e6104b8045a717417b', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(29, '1091b2c41598ea94c4c615b2ba4c8e38f2503f16', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(30, '6cd2363c70fc7e996175692a783dff9d8b7ed919', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(31, 'cb3d82398d13bcef3a2bcd482ba8baa9c22424b8', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(32, 'f4b72cbbbdf66990b5f7d347f24d8b2168031306', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(33, '34002c0cb895991e2d001fa28246f337cc56d40f', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(34, '1a412cdf91ca665bdb9e945029c9c501bc81940c', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(35, '26bb61a2cd43432ee80b8a1348d1d27d5535e392', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(36, 'cb8f897522976022d814fcb874e2266ebb4d8919', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(37, 'bba167a8b1a852e9cb3c47df9a0cac4394d617c5', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(38, '9543ad43f26019ed62b628618f35d704ef0496d2', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(39, '85953177e853337bb75d7f38b1a6c3b60bb0df72', '90', '90', '90', '90', '90', '90', '90', '90', '90', '90', '90', '', '0000-00-00'),
(40, 'b44ef77af1ca64e87ed7d2c7603c8f58ac14dfbc', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(41, '41fccc27f71f2f2418517ac7156e4c390044598d', '20', '556', '59', '589', '89', '8656', '866', '566', '85', '856', '866', '', '0000-00-00'),
(42, '1267b6727baf9a2e44fb5cbb93fbb171d09509dc', '58', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(43, 'd225bcec41219c82f440696423c10de46e1598dd', '175', '60', '89', '18', '10', '8', '44', '18', '', '5', '11', '', '0000-00-00'),
(44, '6b6d6e06f33dfc723f1ff27a0ea33d68d9b8990d', '58', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(45, '25650d07da12be24d32b0d9c3f0c8332180392cc', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(46, '23752a5979bedb0dcadc396bb017b1bcb10d8a37', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(47, 'c95e16970927621231190a0068ccc113c0e3e0e4', '185', '86', '59', '68', '45', '856', '566', '566', '985', '766', '786', '', '0000-00-00'),
(48, '38c0d7b221b5eca1020fc71983221926acf9a888', '58', '566', '566', '455', '655', '566', '565', '698', '599', '466', '869', '', '0000-00-00'),
(49, 'a5fd30b729ba0994a624bfdb91f2472a3131003a', '65', '5', '455', '55', '88', '66', '55', '69', '75', '88', '88', '', '0000-00-00'),
(50, '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', '80', '80', '80', '80', '80', '80', '80', '80', '80', '80', '80', '', '0000-00-00'),
(51, 'a3f2f50c93131d8e728005351a1bfdef1a3425bd', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(52, '46a643f88d7b48710c8d74bf082bb1d919f5ac3a', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(53, 'b6ddf19d2506711522d2e72ad9e294c0e23cf354', '568', '556', '6644', '566', '556', '665', '566', '866', '566', '456', '458', '', '0000-00-00'),
(54, '4ab922693f4d22df3a10774e3286de38f95d5ecd', '180', '90', '120', '60', '18', '38', '28', '15', '30', '45', '25', '', '0000-00-00'),
(55, '2b0c68fc2ba9e4e62e98cb5e13e26ad1e0e359ad', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(56, 'b7fb3d5f1ca3091587c7cb4b731f68c2606d534e', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(57, 'dc6d0fe499b896f0ea80fec4e3a530dcf034c570', '58', '566', '888', '55', '55', '88', '55', '556', '566', '88', '58', '', '0000-00-00'),
(58, 'eccf365c00b52352076042b02c426f6bf491fc41', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(59, '15c817c371946655c05e50fd3147383c25967a78', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(60, '2d0d0db451317f1719d7a10330907c018bfe737d', '190', '100', '10', '10', '15', '7', '18', '0', '11', '8', '8', '', '0000-00-00'),
(61, '9131d8d4c18c0ed81e26200f04708fa9ee45576a', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(62, '6f44aa820cdfc8447533ff54f90ff147155c7462', '191', '50', '60', '80', '15', '11', '7', '0', '5', '0', '15', '', '0000-00-00'),
(63, '13e9c0cec27132b7a6b2140258923810e1ecfc7e', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(64, '76cf279bf243e0a800dc5dfe8ce8ebf2de9a780f', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(65, 'd93cc705f76c8484778d981df8d52198fc2dfcaa', '60', '40', '6', '20', '90', '10', '12', '12', '0', '0', '6', '', '0000-00-00'),
(66, '28d6df3b6d97e5c23b95f7c74ba6c2a5210a3124', '56', '17.5', '60', '15', '24', '11', '13', '0', '0', '11', '18', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `client_token` text NOT NULL,
  `full_name` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `city` text NOT NULL,
  `block` text NOT NULL,
  `street` text NOT NULL,
  `birth_date` text NOT NULL,
  `kind` text NOT NULL,
  `face_img` text NOT NULL,
  `body_img` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tailor_token` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `client_token`, `full_name`, `phone`, `email`, `city`, `block`, `street`, `birth_date`, `kind`, `face_img`, `body_img`, `date_added`, `tailor_token`) VALUES
(12, 'e33ab24347832d8dbd5a8424d01e7a46979696e2', 'علي', '٠٣٦٧٥٧٨٦٥٥٣٥٦', 'mahmoud.elshwaiukh@gmail.com', 'Cairo', 'Hggd', 'Jhf', '', 'male', 'b1e2bcd4-f7ea-48c3-8f9e-9a9cbd90ab8a.jpg', '1553dcc3-221a-42f7-8a65-aa145ecabb8e.jpg', '2021-07-30 21:48:18', '65b440c40a583011f56e530f8bb5a1ffb4a16830'),
(13, '45527467f009fd88ed06ef62857c3195d14cd0f9', 'جمال محمود', '0115555585', 'mahmoud.elshwaiukh@gmail.com', 'مكة المكرمه', 'مكة المكرمة', 'مكة المكرمة', '', 'male', '56aff077-2bb1-4d3b-a298-e80eb5606cdb.jpg', '265f405e-ca71-4680-98b9-f6207813c9cb.jpg', '2021-08-06 17:36:25', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(16, '6764dff5b112afd6359ab0871a8cfeac19ab723e', 'Ahmed Bnook Api', '+966 50 475 1137', 'mahmoud.elshwaiukh@gmail.com', 'Gahah', 'Gadaj', 'Gagdgg', '', 'male', 'a633dbe2-205d-49ec-9d20-f21ad08bdbef.jpg', '06e562ad-21fb-46a3-9497-de03ff8f16d2.jpg', '2021-09-08 07:37:53', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(17, '0773a02b838f56deca442dc8f456c1829efff08e', 'علي', '+966 50 475 1137', 'mahmoud.elshwaiukh@gmail.com', 'Cairo', 'Cairo', 'Cairo', '', 'male', 'f81e4914-b5d4-41a8-9d99-7b04c01795d9.jpg', 'c5edcf7a-d93f-40de-a28a-f9ac07db7efd.jpg', '2021-09-08 07:37:57', 'ee49d2efa29ee7b2ef38d11188e7d84d98979c8c'),
(18, '201abd4fb60a03789ab0e033ce259c6769b72d86', 'Ahmed Bnook Api', '+966 50 475 1137', 'mahmoud.elshwaiukh@gmail.com', 'Cairo', 'Cairo', 'Cairo', '', 'male', 'ce0f7365-7ce6-44cc-a284-c1960e931849.jpg', 'fa0d7662-17f9-48a0-b5b8-3bff65e7da31.jpg', '2021-09-08 07:38:34', 'ee49d2efa29ee7b2ef38d11188e7d84d98979c8c'),
(19, 'af22d5e0e172580e2d53ba1969a2ff4bcb936a33', 'عامر الشهري', '+966 50 475 1137', 'amam@gmail.com', 'الرياض ', 'الورود', 'شارع العرب', '', 'male', 'face.png', '85e2e6b0-7526-4bbd-96b7-b16c879a0842.mp4', '2021-09-20 10:32:46', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(20, 'd159d3715f3f85aca91a492a8abcfbf480c1ec45', 'عامر الشهري', '+966 50 475 1137', 'amam@gmail.com', 'الرياض ', 'الورود', 'شارع العرب', '', 'male', 'face.png', '85e2e6b0-7526-4bbd-96b7-b16c879a0842.mp4', '2021-09-20 10:32:49', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(21, '278ad4c141892afdc83a04222ea28d4dfa80cf6f', 'عامر الشهري', '+966 50 475 1137', 'amam@gmail.com', 'الرياض ', 'الورود', 'شارع العرب', '', 'male', 'face.png', '85e2e6b0-7526-4bbd-96b7-b16c879a0842.mp4', '2021-09-20 10:32:30', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(22, '05414f9ef22d2119db349a6a37d10aba87e6ff8d', 'عامر الشهري', '+966 50 475 1137', 'amam@gmail.com', 'الرياض ', 'الورود', 'شارع العرب', '', 'male', 'face.png', '85e2e6b0-7526-4bbd-96b7-b16c879a0842.mp4', '2021-09-20 10:32:42', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(23, 'b6e238f6e112f20bdc4b68edb42d449b4696510a', 'عامر الشهري', '+966 50 475 1137', 'amam@gmail.com', 'الرياض ', 'الورود', 'شارع العرب', '', 'male', 'face.png', '85e2e6b0-7526-4bbd-96b7-b16c879a0842.mp4', '2021-09-20 10:32:37', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(24, 'c1c9d13b760deef67c094f2a63c45f1739589dde', 'عامر الشهري', '+966 50 475 1137', 'amam@gmail.com', 'الرياض ', 'الورود', 'شارع العرب', '', 'male', 'face.png', '85e2e6b0-7526-4bbd-96b7-b16c879a0842.mp4', '2021-09-20 10:32:25', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(25, 'f902d6bc0c422f6ece61eeb8dbcf1c25d0edea54', 'عامر الشهري', '+966 50 475 1137', 'amam@gmail.com', 'الرياض ', 'الورود', 'شارع العرب', '', 'male', 'face.png', '85e2e6b0-7526-4bbd-96b7-b16c879a0842.mp4', '2021-09-20 10:32:21', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(26, 'df9283b42fee6ac515b3a4e9aa4bf36437e9c339', 'جمال', '٣٥٧٧٦٤٣٣', 'mahmoud.elshwaiukh@gmail.com', 'Test', 'Test', 'Test', '', 'male', 'e09102c3-b6ff-4b48-9366-c0b602affda0.jpg', '97018a2c-ec78-45a7-8ecc-f31058fc2185.jpg', '2021-08-27 23:46:46', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(27, '99c0338a4f7c24b695ca14099641b504fcbd6294', 'سيد', '٠١٠٦٣٦٣٤٥٨٠', 'mahmoud.elshwaiukh@gmail.com', 'القاهرة', 'القاهرة', 'شارع المعز', '', 'male', 'c7ec2db1-d03a-413e-92be-5d4da33a72ac.jpg', 'c99eb478-8f80-40a9-9df8-e0cf2e78494f.jpg', '2021-08-28 00:22:47', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(28, 'a263845c9307aef99c7d23207ce6b333da8ac731', 'سيد', '٠١٠٦٣٦٣٤٥٨٠', 'mahmoud.elshwaiukh@gmail.com', 'القاهرة', 'القاهرة', 'شارع المعز', '', 'male', 'c7ec2db1-d03a-413e-92be-5d4da33a72ac.jpg', 'c99eb478-8f80-40a9-9df8-e0cf2e78494f.jpg', '2021-08-28 00:23:22', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(29, '1be08cec75862a9ece0fc09c833640adb22cfb15', 'يوسف العتيبي', '056 720 8497', 'A. A. Com', 'Aaa', 'غرناطة', 'الورود', '', 'male', 'a35456ba-3dec-42e5-8cf2-c6aeba65f50e.jpg', 'd3d50c58-358b-4ef2-a20e-66f5684f9fbe.jpg', '2021-09-04 15:42:42', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(35, '3b2f91e13ca4497b4a50602419c2f04e66edf6d5', 'الشويخ', '201063634580', '', '', '', '', '', 'male', 'face.png', '', '2021-09-20 10:12:09', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(36, 'bd8744e358560284ef85b203853c0d989fcbd77d', 'الشويخ 2', '201063634580', '', '', '', '', '', 'male', 'face.png', '', '2021-09-20 10:12:12', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(37, '89379e045c5293e14a0d007e64f7236dcd49e270', 'الشويخ 8', '201063634580', 'mahmoud.elshwaiukh@gmail.com', 'القاهرة', 'الشيخ زايد', 'السلام', '', 'male', 'face.png', '', '2021-09-20 10:12:16', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(38, '16be36dad7e6b482d1584d04e04b9f1c2b9a47da', 'الشويخ 9', '6852999', 'mahmoud.elshwaiukh@gmail.com', '', '', '', '', 'male', '38f1663d-8917-4d4e-afc3-4876dc5f5e07.jpg', '06aa7cf2-cad3-462c-8bf0-27cdc695267e.png', '2021-09-15 01:18:56', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(46, '26bb61a2cd43432ee80b8a1348d1d27d5535e392', 'محمود جمال', '01063634580', '', '', '', '', '', 'male', 'face.png', '', '2021-09-20 10:12:55', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(47, 'cb8f897522976022d814fcb874e2266ebb4d8919', 'محمود السيد', '201063634580', 'mahmoud.elshwaiukh@gmail.com', 'القاهرة', 'البستان', 'شارع الجلاء', '', 'male', 'df1d5042-514b-47d7-8a6e-33a2fb106580.jpg', '2a174a58-653a-4ee2-be94-3d1ab4079130.jpg', '2021-09-16 04:28:36', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(50, '85953177e853337bb75d7f38b1a6c3b60bb0df72', 'Mahmoud Mostafa', '+20 114 044 1338', '', '', '', '', '', 'male', 'face.png', '', '2021-09-20 10:12:03', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(51, 'b44ef77af1ca64e87ed7d2c7603c8f58ac14dfbc', 'محمود علي', '201063634580', '', '', '', '', '', 'male', 'face.png', '', '2021-09-20 10:12:06', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(52, '41fccc27f71f2f2418517ac7156e4c390044598d', 'محمد  ابراهيم', '201096798', 'mahmoud.elshwaiukh@gmail.com', '', '', '', '', 'male', 'a65dfb7f-242a-429c-93a4-7abbcef49273.jpg', '4aa6d508-2624-4f4b-9f8b-921629c7d359.jpg', '2021-09-16 05:55:08', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(53, '1267b6727baf9a2e44fb5cbb93fbb171d09509dc', 'Dev Ahmed', '+20 111 102 8251', '', '', '', '', '', 'male', '5346845b-5dca-45fc-b9ed-5f722a6a44f0.jpg', 'e78cb2bb-e7b2-4181-92ec-bb53aa52c5c0.jpg', '2021-09-16 05:56:32', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(54, 'd225bcec41219c82f440696423c10de46e1598dd', 'يحيى الصغير', '0551445638', '', '', '', '', '', 'male', 'face.png', '', '2021-09-20 10:12:48', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(55, '6b6d6e06f33dfc723f1ff27a0ea33d68d9b8990d', 'محمود جمال', '٠١٠٦٣٦٣٤٥٨٠', '', '', '', '', '', 'male', 'a4596304-b8c8-4a0d-affb-91c9a4c13273.jpg', '0b49ab9f-cb3c-439e-949b-67b6634e7bb8.jpg', '2021-09-17 13:22:49', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(56, '25650d07da12be24d32b0d9c3f0c8332180392cc', 'Dev Ahmed', '+20 111 102 8251', 'mahmoud.elshwaiukh@gmail.com', '', '', '', '', 'male', 'bc76cf57-33e5-4f2f-9fe9-76302fae25c5.jpg', '83665164-a33e-4270-8534-cb94c22c8863.jpg', '2021-09-17 13:24:21', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(57, '23752a5979bedb0dcadc396bb017b1bcb10d8a37', 'محمود جمال', '٢٠٧٧٥٥٦٨٧٥٤', '', '', '', '', '', 'male', 'face.png', '', '2021-09-20 10:12:42', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(58, 'c95e16970927621231190a0068ccc113c0e3e0e4', 'محمود ابراهيم', '٢٧٧٥٦٧٨٧٤', '', '', '', '', '', 'male', '0a0855c3-8e94-40ae-938b-a177f82079fe.jpg', 'f3f27bdb-1e55-4b7f-8a02-770b04a1ce09.jpg', '2021-09-17 14:19:46', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(59, '38c0d7b221b5eca1020fc71983221926acf9a888', 'DR. ADEL FATHY FCI', '0100 485 3375', '', '', '', '', '', 'male', '3109553c-e9a5-4a71-a4bb-9f93e9e8ef87.jpg', '5df596a2-7817-4e7a-84a7-477a26156928.jpg', '2021-09-17 14:20:21', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(60, 'a5fd30b729ba0994a624bfdb91f2472a3131003a', 'محمود  علي', '٩٦٦٨٨٥٤', '', '', '', '', '', 'male', '718d9f4b-22c4-4d59-b08c-3d4394d399d3.jpg', '181137dc-880a-49b2-983f-d0d9e0bccbd1.jpg', '2021-09-17 14:24:40', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(61, '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '', '', '', '', '', 'male', 'c249f759-b81d-4698-a5d8-df1ab01210d3.jpg', 'c0499aed-43c6-474f-9078-6318d9075e82.jpg', '2021-09-17 14:25:08', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(62, 'a3f2f50c93131d8e728005351a1bfdef1a3425bd', 'عميل جديد', '3588555', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-09-20 10:14:27', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(63, '46a643f88d7b48710c8d74bf082bb1d919f5ac3a', 'عميل جديد 254885', '235445', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-09-20 07:59:06', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(64, 'b6ddf19d2506711522d2e72ad9e294c0e23cf354', 'محمد محمود', '2545598', '', '', '', '', '', 'male', '6851c9a0-bc17-4c3d-867d-cac7e080fb33.jpg', '7c3c0b03-a745-4556-91ab-c55fe56c8b99.jpg', '2021-09-20 08:01:05', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(65, '4ab922693f4d22df3a10774e3286de38f95d5ecd', 'Ayman Mostafa', '0111 695 5851', '', '', '', '', '', 'male', '9a31dcb3-f9c5-4f51-bb88-c61592514927.jpg', 'f136078e-b303-4c92-ace1-015e62e7187c.jpg', '2021-09-20 15:38:26', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(66, '2b0c68fc2ba9e4e62e98cb5e13e26ad1e0e359ad', 'تحربه 1', '4658955', '', '', '', '', '', 'male', 'a7d418ec-62a0-4d31-acf7-bd48022b1299.jpg', '37ac091c-da61-49a3-a56a-bf432a30ff44.jpg', '2021-09-21 06:45:57', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(67, 'b7fb3d5f1ca3091587c7cb4b731f68c2606d534e', 'تجربة 2', '565865869', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-09-21 06:46:27', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(68, 'dc6d0fe499b896f0ea80fec4e3a530dcf034c570', 'عميل رقم 1', '55689', '', '', '', '', '', 'male', 'cab7ff63-e491-4ca4-a453-77f9b973605c.jpg', 'e9dd074e-3ffd-4fff-bd9f-833211c0602e.jpg', '2021-09-21 07:18:07', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(69, 'eccf365c00b52352076042b02c426f6bf491fc41', 'عميل  رقم 2', '5698', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-09-21 07:18:32', 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f'),
(70, '15c817c371946655c05e50fd3147383c25967a78', 'علي سلمان', '+966 50 609 4466', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-09-23 15:58:55', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(71, '2d0d0db451317f1719d7a10330907c018bfe737d', 'لوبيز', '050 286 6039', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-09-27 09:26:01', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(72, '9131d8d4c18c0ed81e26200f04708fa9ee45576a', 'سوسو', '054 793 1584', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-09-27 18:26:30', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(73, '6f44aa820cdfc8447533ff54f90ff147155c7462', 'علي مبروك', '+966 55 972 3331', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-10-04 12:40:08', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(74, '13e9c0cec27132b7a6b2140258923810e1ecfc7e', 'سلطان عبدالسلام', '059 072 2626', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-10-04 14:01:22', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(75, '76cf279bf243e0a800dc5dfe8ce8ebf2de9a780f', 'محمد الملحم', '054 773 3011', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-10-08 13:22:45', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd'),
(76, 'd93cc705f76c8484778d981df8d52198fc2dfcaa', 'ابوسلطان ٢', '+966 50 804 4459', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-10-14 06:10:19', 'fb2a24c13e4f207386dd247bee0c5803f913402b'),
(77, '28d6df3b6d97e5c23b95f7c74ba6c2a5210a3124', 'أمين  عامل', '0503289330', '', '', '', '', '', 'male', 'face.png', 'body.png', '2021-10-21 12:54:09', 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `tailor_token` text COLLATE utf8_unicode_ci NOT NULL,
  `client_token` text COLLATE utf8_unicode_ci NOT NULL,
  `client_name` text COLLATE utf8_unicode_ci NOT NULL,
  `client_phone` text COLLATE utf8_unicode_ci NOT NULL,
  `price` text COLLATE utf8_unicode_ci NOT NULL,
  `paid` int(11) NOT NULL,
  `deliver_date` text COLLATE utf8_unicode_ci NOT NULL,
  `max_deliver` text COLLATE utf8_unicode_ci NOT NULL,
  `is_urgent` text COLLATE utf8_unicode_ci NOT NULL,
  `count` text COLLATE utf8_unicode_ci NOT NULL,
  `fabric_type` text COLLATE utf8_unicode_ci NOT NULL,
  `custom_type` text COLLATE utf8_unicode_ci NOT NULL,
  `length` text COLLATE utf8_unicode_ci NOT NULL,
  `width` text COLLATE utf8_unicode_ci NOT NULL,
  `shoulder` text COLLATE utf8_unicode_ci NOT NULL,
  `hand` text COLLATE utf8_unicode_ci NOT NULL,
  `hand_width` text COLLATE utf8_unicode_ci NOT NULL,
  `neck` text COLLATE utf8_unicode_ci NOT NULL,
  `kalab` text COLLATE utf8_unicode_ci NOT NULL,
  `sadah` text COLLATE utf8_unicode_ci NOT NULL,
  `cup` text COLLATE utf8_unicode_ci NOT NULL,
  `cup_width` text COLLATE utf8_unicode_ci NOT NULL,
  `cup_type` text COLLATE utf8_unicode_ci NOT NULL,
  `floor_width` text COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `date_added` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `tailor_token`, `client_token`, `client_name`, `client_phone`, `price`, `paid`, `deliver_date`, `max_deliver`, `is_urgent`, `count`, `fabric_type`, `custom_type`, `length`, `width`, `shoulder`, `hand`, `hand_width`, `neck`, `kalab`, `sadah`, `cup`, `cup_width`, `cup_type`, `floor_width`, `status`, `date_added`) VALUES
(47, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '20', 0, '2021-09-27', '50', 'true', '5', 'لل', 'تل', '', '', '585', '58', '455', '76', '866', '985', '452', '45', '', '855', 'complete', '2021-09-19'),
(48, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '50', 0, '2021-09-21', '58', 'false', '4', 'بلع', 'اال', '55', '55', '45', '98', '55', '88', '66', '85', '66', '44', '', '95', 'complete', '2021-09-19'),
(49, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'a5fd30b729ba0994a624bfdb91f2472a3131003a', 'محمود  علي', '٩٦٦٨٨٥٤', '48', 0, '2021-09-29', '25', 'false', '58', 'بفغ', 'بب', '65', '5', '55', '88', '66', '55', '69', '75', '88', '88', '', '455', 'active', '2021-09-19'),
(50, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'a5fd30b729ba0994a624bfdb91f2472a3131003a', 'محمود  علي', '٩٦٦٨٨٥٤', '48', 0, '2021-09-29', '25', 'false', '58', 'بفغ', 'بب', '65', '5', '55', '88', '66', '55', '69', '75', '88', '88', '', '455', 'active', '2021-09-19'),
(51, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '58', 0, '2021-09-29', '2', 'false', '2', 'Test', 'Test', '58', '58', '88', '85', '88', '988', '55', '455', '555', '88', '', '999', 'active', '2021-09-20'),
(52, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '38c0d7b221b5eca1020fc71983221926acf9a888', 'DR. ADEL FATHY FCI', '0100 485 3375', '50', 0, '2021-09-23', '20', 'true', '2', 'Test', 'Test', '58', '566', '455', '655', '566', '565', '698', '599', '466', '869', '', '566', 'delivered', '2021-09-20'),
(53, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '4ab922693f4d22df3a10774e3286de38f95d5ecd', 'Ayman Mostafa', '0111 695 5851', '58', 0, '2021-09-28', '6', 'false', '3', 'Test', 'Test', '180', '90', '60', '18', '38', '28', '15', '30', '45', '25', '', '120', 'active', '2021-09-20'),
(54, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'c95e16970927621231190a0068ccc113c0e3e0e4', 'محمود ابراهيم', '٢٧٧٥٦٧٨٧٤', '20', 0, '2021-10-20', '8', 'true', '3', 'قماش', 'تفصيل سعودي', '185', '86', '68', '45', '856', '566', '566', '985', '766', '786', '', '59', 'complete', '2021-09-20'),
(55, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '85953177e853337bb75d7f38b1a6c3b60bb0df72', 'Mahmoud Mostafa', '+20 114 044 1338', '50', 0, '2021-09-29', '20', 'false', '5', 'Test', 'Tset', '58', '56', '56', '555', '55', '566', '236', '566', '56', '55', '', '59', 'active', '2021-09-21'),
(56, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '50', 0, '2021-09-30', '2', 'false', '2', 'Test', 'Test', '80', '80', '80', '80', '80', '80', '80', '80', '80', '80', '', '80', 'delivered', '2021-09-21'),
(57, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '41fccc27f71f2f2418517ac7156e4c390044598d', 'محمد  ابراهيم', '201096798', '50', 0, '2021-09-23', '20', 'false', '2', 'Test', 'Test', '20', '556', '589', '89', '8656', '866', '566', '85', '856', '866', '', '59', 'complete', '2021-09-21'),
(58, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', 'd225bcec41219c82f440696423c10de46e1598dd', 'يحيى الصغير', '0551445638', '120', 0, '1969-12-31', '5', 'false', '2', 'سوبر', 'سعودي', '175', '60', '18', '10', '8', '44', '18', '', '5', '11', '', '89', 'delivered', '2021-09-21'),
(59, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'dc6d0fe499b896f0ea80fec4e3a530dcf034c570', 'عميل رقم 1', '55689', '58', 0, '1969-12-31', '155', 'false', '556', 'Fgh', 'Fg', '58', '566', '55', '55', '88', '55', '556', '566', '88', '58', '', '888', 'delivered', '2021-09-23'),
(60, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'dc6d0fe499b896f0ea80fec4e3a530dcf034c570', 'عميل رقم 1', '55689', '58', 0, '1969-12-31', '50', 'false', '25', 'Dgh', 'Fhh', '58', '566', '55', '55', '88', '55', '556', '566', '88', '58', '', '888', 'complete', '2021-09-26'),
(61, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'dc6d0fe499b896f0ea80fec4e3a530dcf034c570', 'عميل رقم 1', '55689', '25', 0, '1969-12-31', '58', 'false', '5', 'Test', 'Test', '58', '566', '55', '55', '88', '55', '556', '566', '88', '58', '', '888', 'delivered', '2021-09-26'),
(62, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '2b0c68fc2ba9e4e62e98cb5e13e26ad1e0e359ad', 'تحربه 1', '4658955', '58', 0, '2021-09-30', '5', 'false', '5', 'Test', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', 'complete', '2021-09-26'),
(63, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '58', 0, '2021-09-30', '5', 'false', '5', 'Test', 'Test', '80', '80', '80', '80', '80', '80', '80', '80', '80', '80', '', '80', 'active', '2021-09-26'),
(64, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'dc6d0fe499b896f0ea80fec4e3a530dcf034c570', 'عميل رقم 1', '55689', '800', 0, '2021-09-30', '25', 'false', '88', 'Dfggh', 'Tff', '58', '566', '55', '55', '88', '55', '556', '566', '88', '58', '', '888', 'complete', '2021-09-26'),
(65, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'b6ddf19d2506711522d2e72ad9e294c0e23cf354', 'محمد محمود', '2545598', '250', 500, '2021-09-30', '5', 'false', '5', 'ممتاز', 'سعودي', '568', '556', '566', '556', '665', '566', '866', '566', '456', '458', '', '6644', 'complete', '2021-09-26'),
(66, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '20', 50, '2021-09-30', '20', 'true', '10', 'ممتاز', 'سعودي', '80', '80', '80', '80', '80', '80', '80', '80', '80', '80', '', '80', 'delivered', '2021-09-26'),
(67, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '38c0d7b221b5eca1020fc71983221926acf9a888', 'DR. ADEL FATHY FCI', '0100 485 3375', '50', 50, '2021-10-18', '12', 'true', '10', 'ممتاز', 'سعودب', '58', '566', '455', '655', '566', '565', '698', '599', '466', '869', '', '566', 'delivered', '2021-09-26'),
(68, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '50', 50, '2021-10-13', '12', 'true', '5', 'ممتاز', 'سعودي', '80', '80', '80', '80', '80', '80', '80', '80', '80', '80', '', '80', 'complete', '2021-09-26'),
(69, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '44e4b78ef7d6058c8d7962eae0805cc90de7a5cc', 'Omar Raway', '+20 109 876 5107', '50', 60, '2021-10-20', '12', 'true', '5', 'ممتاز', 'سعودي', '80', '80', '80', '80', '80', '80', '80', '80', '80', '80', '', '80', 'complete', '2021-09-26'),
(70, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', '2d0d0db451317f1719d7a10330907c018bfe737d', 'لوبيز', '050 286 6039', '180', 200, '2021-10-08', '8', 'true', '4', 'سوبر ياباني', 'سعودي', '190', '100', '10', '15', '7', '18', '0', '11', '8', '8', '', '10', 'complete', '2021-09-27'),
(71, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', '9131d8d4c18c0ed81e26200f04708fa9ee45576a', 'سوسو', '054 793 1584', '100', 200, '2021-09-30', '2', 'false', '4', 'كوري', 'سعودي', '', '', '', '', '', '', '', '', '', '', '', '', 'delivered', '2021-09-27'),
(72, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', '6f44aa820cdfc8447533ff54f90ff147155c7462', 'علي مبروك', '+966 55 972 3331', '100', 200, '2021-10-11', '', 'false', '5', 'سوبر ١١', 'اماراتي', '191', '50', '80', '15', '11', '7', '0', '5', '0', '15', '', '60', 'active', '2021-10-04'),
(73, 'fb2a24c13e4f207386dd247bee0c5803f913402b', 'd93cc705f76c8484778d981df8d52198fc2dfcaa', 'ابوسلطان ٢', '+966 50 804 4459', '300', 50, '2021-10-16', '', 'true', '2', 'ياباني', 'قطري', '60', '40', '20', '90', '10', '12', '12', '0', '0', '6', '', '6', 'active', '2021-10-14'),
(74, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', '28d6df3b6d97e5c23b95f7c74ba6c2a5210a3124', 'أمين  عامل', '0503289330', '300', 200, '2021-10-28', '5', 'true', '3', 'ملبى', 'سعودي', '56', '17.5', '15', '24', '11', '13', '0', '0', '11', '18', '', '60', 'active', '2021-10-21'),
(75, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', '28d6df3b6d97e5c23b95f7c74ba6c2a5210a3124', 'أمين  عامل', '0503289330', '100', 50, '2021-10-30', '', 'false', '1', 'ملبى', '١', '56', '17.5', '15', '24', '11', '13', '0', '0', '11', '18', '', '60', 'active', '2021-10-21'),
(76, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', '38c0d7b221b5eca1020fc71983221926acf9a888', 'DR. ADEL FATHY FCI', '0100 485 3375', '200', 500, '2021-10-21', '20', 'false', '5', 'ممتاز', 'سعودي', '58', '566', '455', '655', '566', '565', '698', '599', '466', '869', '', '566', 'active', '2021-10-21'),
(77, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'a5fd30b729ba0994a624bfdb91f2472a3131003a', 'محمود  علي', '٩٦٦٨٨٥٤', '200', 600, '2021-10-25', '10', 'true', '5', 'ممتاز', 'سعودي', '65', '5', '55', '88', '66', '55', '69', '75', '88', '88', '', '455', 'active', '2021-10-21');

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` int(11) NOT NULL,
  `user_token` text NOT NULL,
  `name` text NOT NULL,
  `contact_number` text NOT NULL,
  `contact_email` text NOT NULL,
  `url` text NOT NULL,
  `type` text NOT NULL,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `address` text NOT NULL,
  `post_number` int(11) NOT NULL,
  `area` text NOT NULL,
  `logo` text NOT NULL,
  `store_pic` text,
  `tax_number` text NOT NULL,
  `tax_ratio` int(11) NOT NULL DEFAULT '15',
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`id`, `user_token`, `name`, `contact_number`, `contact_email`, `url`, `type`, `country`, `city`, `address`, `post_number`, `area`, `logo`, `store_pic`, `tax_number`, `tax_ratio`, `date_created`) VALUES
(4, '65b440c40a583011f56e530f8bb5a1ffb4a16830', 'متجر رقم ٥٠٠', '011008655555', 'mahmoud.elshwaiukh@gmail.com', 'HTTPS:// bnok ney', '', 'مصر', 'اللداري', 'اسيوط', 258996, 'القاهره', 'e8c10580-3f1e-422e-8861-082eb2925075.jpg', 'edad2092-e8e5-455b-8375-2f548f3592b3.jpg', '', 15, '2021-07-14'),
(7, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'وسام أنيق', '7765678844', 'mahmoud.elshwaiukh@gmail.com', 'test.com', '', 'مصر', 'القاهرة', 'القاهرة', 19573, 'القاهرة', '16d4379b-a2a3-4db2-b85e-ca94f537e7b4.jpg', '0235dcb9-b73b-44c9-875e-d0f81d970f8b.jpg', '123456789', 20, '2021-10-06'),
(8, '6111252f3d8e20bb4656f791d5475ec0875f7653', 'متجر9503438', '', '', '', '', '', '', '', 0, '', '', '', '', 15, '0000-00-00'),
(9, 'ee49d2efa29ee7b2ef38d11188e7d84d98979c8c', 'متجر الأمانه', '0155655', 'mahmoud.elshwaiukh@gmail.com', 'test.com', '', 'مصر ', 'القاهره', 'القاهره', 28888, 'القاهرة', '4f75b25f-f7a6-4da2-ab6e-229b7d92e272.jpg', '6e24ff22-5ea0-406b-a8f0-5b8beefed9ec.jpg', '', 15, '2021-08-07'),
(10, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', 'خياط ١', '', '', '', '', '', '', '', 0, '', '269f92ad-e693-4bd9-b7b2-68ddf9e949c8.jpg', '7ada4c5f-cb88-4b67-97ee-fe9e966e2ee0.jpg', '1101115555', 15, '2021-10-21'),
(11, '43d89929d80b4d50fca9ba355df8f96ac35b6b19', 'متجر2873635', '', '', '', '', '', '', '', 0, '', '', '', '', 15, '0000-00-00'),
(12, '08e8c613d96b55e88323e475519e9a606b993b73', 'متجر9224041', '', '', '', '', '', '', '', 0, '', '', '', '', 15, '0000-00-00'),
(13, 'fb2a24c13e4f207386dd247bee0c5803f913402b', 'متجر9038349', '', '', '', '', '', '', '', 0, '', 'https://stakfort.com/tailor/assets/photo.png', 'https://stakfort.com/tailor/assets/photo.png', '', 15, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tailors`
--

CREATE TABLE `tailors` (
  `id` int(11) NOT NULL,
  `token` text NOT NULL,
  `user_name` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `password` text NOT NULL,
  `register_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tailors`
--

INSERT INTO `tailors` (`id`, `token`, `user_name`, `email`, `phone`, `password`, `register_date`) VALUES
(3, '65b440c40a583011f56e530f8bb5a1ffb4a16830', 'mahmoud', 'mahmoud.elshwaiukh@gmail.com', '2794974', '123456789', '0000-00-00 00:00:00'),
(6, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'Mohamed', 'mahmoud.elshwaiukh@gmail.com', '', '123456', '0000-00-00 00:00:00'),
(8, 'ee49d2efa29ee7b2ef38d11188e7d84d98979c8c', 'Mahmoud92', 'mahmoud.elshwaiukh@gmail.com', '', 'qweasdzxc', '0000-00-00 00:00:00'),
(9, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', 'عادل', 'aaahmari@gmail.com ', '', 'Aa123123', '0000-00-00 00:00:00'),
(10, '43d89929d80b4d50fca9ba355df8f96ac35b6b19', 'Bghrtsa', 'Iamwaitingyou@hotmail.com ', '', '293541', '0000-00-00 00:00:00'),
(11, '08e8c613d96b55e88323e475519e9a606b993b73', 'Mooo', 'moo', '', '123456', '0000-00-00 00:00:00'),
(12, 'fb2a24c13e4f207386dd247bee0c5803f913402b', 'عبدالرحمن الاحمري ', 'dm3talam1@gmail.com', '', 'acader123', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `tailor_token` text NOT NULL,
  `task_name` text NOT NULL,
  `task_start` date NOT NULL,
  `task_end` date NOT NULL,
  `status` text NOT NULL,
  `days_num` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `tailor_token`, `task_name`, `task_start`, `task_end`, `status`, `days_num`) VALUES
(16, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'مهمة رقم 20', '2021-08-06', '2021-08-14', '', 8),
(17, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'تفصيل ثوب جديد', '2021-08-06', '2021-08-11', '', 5),
(18, 'ee49d2efa29ee7b2ef38d11188e7d84d98979c8c', 'تفصيل ثوب', '2021-08-07', '2021-08-15', '', 8),
(19, 'ee49d2efa29ee7b2ef38d11188e7d84d98979c8c', 'مهمة رقم 2', '2021-08-07', '1969-12-31', '', 0),
(20, 'e9b256de5609f83b8dae6a49d6bd7da20b5611bd', 'تفصيل ثوب', '2021-08-24', '2021-08-29', '', 5),
(22, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'Test', '2021-09-15', '2021-09-15', '', 0),
(23, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'تجربه', '2021-09-16', '2021-09-21', '', 5),
(24, 'b44bf9f0e676a9bad4d1ce73f93c98428cfdc35f', 'تجربة اليوم', '2021-09-16', '2021-09-16', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `body_measurments`
--
ALTER TABLE `body_measurments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tailors`
--
ALTER TABLE `tailors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `body_measurments`
--
ALTER TABLE `body_measurments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tailors`
--
ALTER TABLE `tailors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
